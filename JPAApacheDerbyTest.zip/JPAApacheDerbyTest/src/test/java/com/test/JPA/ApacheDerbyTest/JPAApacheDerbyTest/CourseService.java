package com.test.JPA.ApacheDerbyTest.JPAApacheDerbyTest;

import java.util.List;
import java.util.Optional;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseService {
	
	@Autowired
	private CourseRepository courseRepository;
	
//	private List<Course> courses = new ArrayList (Arrays.asList(
//			new Course("Spring","Spring Boot", "Spring Boot description"),
//			new Course("Java","Core Java", "Core java description"),
//			new Course("Python","Python script", "Spring Boot framework"),
//			new Course("J2EE","J2EE Boot", "J2EE Boot framework")		
//			));
	
	public List<Course> getAllCourses() {
		List<Course> courses = new ArrayList<>();
		courseRepository.findAll().forEach(courses::add);
		return courses;
	}
	
	public Optional<Course> getCourse(String id) {
//		return courses.stream().filter(t->t.getId().equals(id)).findFirst().get();
		return courseRepository.findById(id);
	}

	public void addCourse(Course topic) {
		//topics.add(topic);
		courseRepository.save(topic);
	}

	public void updateCourse(Course topic, String id) {
		courseRepository.save(topic);
//		for(int i=0;i<courses.size();i++) {
//			String id1=courses.get(i).getId();
//			if(id1.equals(id)) {
//				courses.set(i, topic);
//				return;
//			}
//		}
	}

	public void deleteCourse(String id) { 
		//courses.removeIf(t->t.getId().equals(id));
		courseRepository.deleteById(id);
	}
	
	
}
