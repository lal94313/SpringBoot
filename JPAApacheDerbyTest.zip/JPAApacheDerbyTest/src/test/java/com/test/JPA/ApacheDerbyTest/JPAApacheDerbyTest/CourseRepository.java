package com.test.JPA.ApacheDerbyTest.JPAApacheDerbyTest;

import org.springframework.data.repository.CrudRepository;

public interface CourseRepository extends CrudRepository<Course,String>{

}
